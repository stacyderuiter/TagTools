function    r = loadprh(tag,varargin)
%
%    loadprh(tag,...)
%    Load variables from the prh file associated with a tag deployment.
%    Examples:
%    load all the variables in the prh file of md04_287a
%       loadprh('md04_287a')
%    load just some variables from the prh file of md04_287a
%       loadprh('md04_287a','p','fs')
%    equivalently:
%       loadprh md04_287a
%       loadprh md04_287a p fs
%
%    mark johnson
%    majohnson@whoi.edu
%    last modified: 13 May 2006

if nargout==1,
   r = 0 ;
end

if nargin<1,
   help loadprh
   return
end

% try to make filename
fname = makefname(tag,'PRH') ;
if isempty(fname),
   return
end

% check if the file exists
if ~exist(fname,'file'),
   if nargout==0,
      fprintf(' Unable to find prh file %s - check directory and settagpath\n',fname) ;
   end
   return
end

% load the variables from the file
s = load(fname,varargin{:}) ;
names = fieldnames(s) ;

% push the variables into the calling workspace
for k=1:length(names),
   assignin('caller',names{k},getfield(s,names{k})) ;
end

if nargout~=0,
   r = length(names) ;
end
