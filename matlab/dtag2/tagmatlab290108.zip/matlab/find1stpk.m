function    y = find1stpk(X,relth,absth)
%
%     y = find1stpk(X,relth,absth)
%     Find the first peak in X with level greater than
%     either relth*max(X) or absth.
%     y is the index of the first peak interpolated to sub-
%     sample resolution using quadratic interpolation.
%
%     mark johnson
%     majohnson@whoi.edu
%     Last modified: 26 June 2007

y = [] ;

if nargin<2,
   help find1stpk
   return
end

if nargin<3 | isempty(absth),
   absth = 0 ;
end

if isempty(relth),
   relth = 0 ;
end

[mx nn] = max(X) ;
D = diff(X) ;
y = NaN*ones(size(X,2),1) ;
p = NaN*ones(size(X,2),3) ;
th = min(relth*mx',absth) ;

for k=1:size(X,2),        % find 1st peak higher than relth*max(X) and absth
   yy = min(find(X(2:end-1,k)>th(k) & D(1:end-1,k)>=0 & D(2:end,k)<0)) ;
   if ~isempty(yy),
      if yy==1, y(k) = 2 ;
      elseif yy==size(X,1), y(k) = yy-1 ;
      else y(k) = yy ;
      end
      p(k,:) = X(y(k)+(-1:1),k)' ;
   end
end

% now refine the estimate with a quadratic fit
ym = 0.5*(p(:,1)-p(:,3))./(p(:,3)-2*p(:,2)+p(:,1)) ;
y = min([size(X,1)+0*y max([1+0*y real(y+ym)]')']')' ;
