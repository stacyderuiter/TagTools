function     [v,a]=vertical(p,fs,fc)
%
%     [v,a]=vertical(p,fs,[fc])
%     Estimate the vertical velocity and acceleration from the depth time
%     series.
%     p is the depth time series in meters, sampled at fs Hz.
%     fc is the smoothing filter cut-off frequency in Hz. Default value is
%     0.2 Hz (5 second time constant).
%
%     v is the vertical velocity in m/s
%     a is the vertical acceleration in m^2/s
%     v and a have the same size as p.
%
%     mark johnson, WHOI
%     mjohnson@whoi.edu
%     November 2003

if nargin<2,
   help('vertical') ;
   return
end

if nargin==2,
   fc = 0.2 ;
end

k = find(~isnan(p)) ;
v = p ;
a = p ;

h = fir1(60,fc/(fs/2));   % low-pass filter
v(k) = filtfilt(h,[1 0],[0;diff(p(k))]*fs) ;

if nargout==2,
   a(k) = filtfilt(h,[1 0],[0;diff(diff(p(k)));0]*fs^2) ;
end
