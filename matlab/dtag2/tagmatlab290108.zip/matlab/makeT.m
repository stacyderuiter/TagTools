function    T = makeT(p,r,h)
%
%      T = makeT(p,r,h) or
%      T = makeT([p,r,h])
%      Make a compound transformation matrix out of elemental
%      pitch, roll, and heading rotations. Inputs are in radians.
%      T = H*P*R
%      To rotate a basis, post multiply by T.
%      To transform a vector sensor measurement, pre-multiply by T'.
%
%      mark johnson, WHOI
%      majohnson@whoi.edu
%      Last modified: 18 Nov. 2005

if nargin~=1 & nargin~=3,
   help makeT
   return
end

if nargin==1,
   h = p(3) ;
   r = p(2) ;
   p = p(1) ;
end

P = [cos(p) 0 -sin(p);0 1 0;sin(p) 0 cos(p)] ;
R = [1 0 0;0 cos(r) -sin(r);0 sin(r) cos(r)] ;
H = [cos(h) -sin(h) 0;sin(h) cos(h) 0;0 0 1] ;
T = H*P*R ;
