function    h=plott(p,fs,reverse)
%
%    h=plott(p,fs,reverse)
%   Plot sensor time series, p, sampled at fs Hertz against time in seconds
%   By default, plott shows the y-axis reversed as for a dive profile.
%   To prevent reversal, use:
%    plott(s,fs,0)
%   where s is the time series to plot.
%   Optionally returns a handle to the line plotted.
%
%   mark johnson, WHOI
%   majohnson@whoi.edu
%   5 July, 2007

if nargin<2,
   help plott
   return
end

hh=plot((1:size(p,1))/fs,p); grid
if nargin<3 | isempty(reverse) | reverse==1,
   set(gca,'YDir','reverse') ;
end

xlabel('Time since tag on, seconds')
ylabel('Sensor value')

if nargout==1,
   h = hh ;
end
