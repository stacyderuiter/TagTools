function    gettagpath
%
%    gettagpath
%    Prints the paths selected for tag data using settagpath.m
%
%    mark johnson
%    majohnson@whoi.edu
%    last modified: 13 May 2006

global TAG_PATHS

if isempty(TAG_PATHS),
   fprintf(' No tag data paths currently selected\n') ;
end

fnames = fieldnames(TAG_PATHS) ;
for k=1:length(fnames),
   fprintf(' %s path set to %s\n', fnames{k},getfield(TAG_PATHS,fnames{k}))
end
