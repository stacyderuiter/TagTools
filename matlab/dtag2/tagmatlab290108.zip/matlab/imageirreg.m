function    imageirreg(x,y,R)
%
%    imageirreg(x,y,R)
%    Irregular grid image.
%
%    mark johnson, WHOI
%    majohnson@whoi.edu
%    12 December, 2006

if nargin<3,
   help imageirreg
   return
end

x = x(:)' ;
y = y(:)' ;
if length(x)~=size(R,1) | length(y)~=size(R,2),
   fprintf('R must be length(x) by length(y)\n')
   return
end

xdiff = [diff(x) x(end)-x(end-1)] ;
X = [0;0;1;1]*xdiff+ones(4,1)*x ;

Y = [0;1;1;0]*ones(1,length(x)) ;
ydiff = [diff(y) y(end)-y(end-1)] ;

for k=1:length(y),
   patch(X,ydiff(k)*Y+y(k),R(:,k)') ;
end

shading flat
axis tight
set(gca,'YDir','reverse')
box on
