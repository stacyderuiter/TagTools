function    T = finddives(p,fs,th,surface)
%
%    T = finddives(p,fs,[th,surface])
%    Find time cues for the edges of dives.
%    p is the depth time series in meters, sampled at fs Hz.
%    th is the threshold in m at which to recognize a dive - dives
%    more shallow than th will be ignored. The default value for th is 10m.
%    surface is the depth in meters at which it is considered that the
%    animal has reached the surface. Default value is 1.
%
%    T is the matrix of cues with columns:
%    [start_cue end_cue max_depth cue_at_max_depth mean_depth mean_compression]
%
%    If there are n dives deeper than th in p, then T will be an nx6 matrix. Partial
%    dives at the beginning or end of the recording will be ignored - only dives that
%    start and end at the surface will appear in T. 
%
%    mark johnson, WHOI
%    mjohnson@whoi.edu
%    last modified: 25 October 2005

if nargin<2,
   help('finddives') ;
   return
end

if nargin<3,
   th = 10 ;
end

if nargin<4,
   surface = 1 ;        % maximum p value for a surfacing (was 2)
end

if fs>1000,
   fprintf('Suspicious fs of %d Hz - check\n', round(fs)) ;
   return
end

searchlen = 10 ;        % how far to look in seconds to find actual surfacing
dpthresh = 0.25 ;        % vertical velocity threshold for surfacing
dp_lp = 0.5 ;           % low-pass filter frequency for vertical velocity

% first remove any NaN at the start of p
% (these are used to mask bad data points and only occur in a few data sets)
kgood = find(~isnan(p)) ;
p = p(kgood) ;
tgood = (min(kgood)-1)/fs ;

% find threshold crossings and surface times
tth = find(diff(p>th)>0) ;
tsurf = find(p<surface) ;
ton = 0*tth ;
toff = ton ;
k = 0 ;

% sort through threshold crossings to find valid dive start and end points
for kth=1:length(tth) ;
   if all(tth(kth)>toff),
      ks0 = find(tsurf<tth(kth)) ;
      ks1 = find(tsurf>tth(kth)) ;
      if ~isempty(ks0) & ~isempty(ks1)
         k = k+1 ;    
         ton(k) = max(tsurf(ks0)) ;
         toff(k) = min(tsurf(ks1)) ;
      end
   end
end

% truncate dive list to only dives with starts and stops in the record
ton = ton(1:k) ;
toff = toff(1:k) ;

% filter vertical velocity to find actual surfacing moments
[b a] = butter(4,dp_lp/(fs/2)) ;
dp = filtfilt(b,a,[0;diff(p)]*fs) ;

% for each ton, look back to find last time whale was at the surface
% for each toff, look forward to find next time whale is at the surface
dmax = zeros(length(ton),2) ;
for k=1:length(ton),
   ind = ton(k)+(-round(searchlen*fs):0) ;
   ind = ind(find(ind>0)) ;
   ton(k) = ind(max(find(dp(ind)<dpthresh))) ;
   ind = toff(k)+(0:round(searchlen*fs)) ;
   ind = ind(find(ind<=length(p))) ;
   toff(k) = ind(min(find(dp(ind)>-dpthresh))) ;
   [dm km] = max(p(ton(k):toff(k))) ;
   dmax(k,:) = [dm (ton(k)+km-1)/fs+tgood] ;
end

% measure dive statistics
pmean = 0*ton ;
pcomp = pmean ;
for k=1:length(ton),
   pdive = p(ton(k):toff(k)) ;
   pmean(k) = mean(pdive) ;
   pcomp(k) = mean((1+0.1*pdive).^(-1)) ;
end
 
% assemble output
T = [[ton toff]/fs+tgood dmax pmean pcomp] ;

