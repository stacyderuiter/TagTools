function     [x,afs,rcue]=tagwavread(tag,cue,secs)
%
%     [x,afs,rcue]=tagwavread(tag,cue,secs)
%     Read audio data from a sequence of wav files recorded by the DTAG
%     Supports tag1 and tag2.
%     tag is the full deployment name e.g. sw05_199a
%     cue is the time of the start of the desired extract. cue can be
%        in any of the acceptable time forms (see tagcue for a list).
%        Only one cue is allowed - for multiple cues use lookupcues.m
%     secs is the length of the extract in seconds. Can be a fraction
%        of a second.
%
%     Returns:
%     x is the signal vector or matrix (for multi-channel tag data) with 
%        a channel in each column.
%     afs is the audio sampling rate of the signal in x.
%     rcue is the seconds since tag-on at the start of the extract x.
%
%     Make sure the paths to tag data have been declared
%     using settagpath.m
%
%     mark johnson, WHOI
%     majohnson@whoi.edu
%     Last modified: 13 May 2006

x = [] ;
afs = [] ;
rcue = [] ;

if nargin<3,
   help tagwavread
   return
end

[c,t,s,ttype,fs,id,wavf] = tagcue(cue,tag) ;
if isempty(c), return, end
rcue = c(3) ;

f = fopen(wavf,'r') ;
if f~=-1,
   fclose(f) ;
else
   fprintf('Unable to open file %s\n', wavf) ;
   return ;
end

[ss afs] = wavread16(wavf,'size') ;

% prepare to read secs seconds or to end of file
smax = floor(min([c(2)+secs*afs+1 ss(1)])) ;

% actual number of seconds to read from 1st file
ns = (smax-c(2))/afs ;
x = wavread16(wavf,[round(c(2)) smax]) ;

if ns<secs,
   ks = strfind(wavf,'.') ;
   if isempty(ks),
      wavf = sprintf('%s%02d',wavf(1:end-2),c(1)+1) ;
   else
      wavf = sprintf('%s%02d%s',wavf(1:ks-3),c(1)+1,wavf(ks:end)) ;
   end
   f = fopen(wavf,'r') ;
   if f~=-1,
      fclose(f) ;
      x = [x;wavread16(wavf,[1 round((secs-ns)*afs)])] ;
   else
      fprintf('Unable to open file %s, x is short\n', wavf) ;
   end
end
