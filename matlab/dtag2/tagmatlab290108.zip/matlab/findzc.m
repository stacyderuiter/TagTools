function    K = findzc(x,TH,Tmax)
%
%    K = findzc(x,TH,Tmax)
%    EXPERIMENTAL - SUBJECT TO CHANGE!!
%    Find cues to each positive zero-crossing in vector x.
%    TH is the magnitude threshold for detecting a zero-crossing. 
%    T is a 2-vector containing the minimum duration and maximum duration 
%    allowable for a zero-crossing half-cycle. To be accepted as a zero-crossing,
%    the signal must pass from below -TH to above TH or visa-versa. If
%    optional Tmax is given, the threshold crossings can be no more than Tmax
%    samples apart.
%  
%    Output: K is a nx2 matrix [Ks,Kf,S], where Ks contains the cue of
%    the first threshold-crossing in samples, Kf contains the cue of the second
%    threshold-crossing in samples. S contains the sign of each zero-crossing
%    (1 = positive-going, -1 = negative-going).
%
%    mark johnson, WHOI
%    majohnson@whoi.edu
%    last modified: January 2008

K = [] ;

if nargin<2,
   help findzc
   return
end

xtp = diff(x>TH) ;
xtn = diff(x<-TH) ;
kpl = find(xtp>0) ;
kpt = find(xtp<0) ;
knl = find(xtn>0) ;
knt = find(xtn<0) ;

K = zeros(length(kpl)+length(knl),3) ;
cnt = 0 ;
SIGN = 1 ;

while min([length(kpl),length(kpt),length(knl),length(knt)])>0,
   if SIGN==1,
      kk = max(find(knt<=kpl(1))) ;
      if ~isempty(kk),
         cnt = cnt+1 ;
         K(cnt,:) = [knt(kk),kpl(1),SIGN] ;
         if length(knt)>kk,
            knt = knt(kk+1:end) ;
         else
            knt = [] ;
         end
         kk = max(find(knl<=kpl(1))) ;
         if ~isempty(kk) & length(knl)>kk,
            knl = knl(kk+1:end) ;
         else
            knl = [] ;
         end
      end
      SIGN = -1 ;

   else
      kk = max(find(kpt<=knl(1))) ;
      if ~isempty(kk),
         cnt = cnt+1 ;
         K(cnt,:) = [kpt(kk),knl(1),SIGN] ;
         if length(kpt)>kk,
            kpt = kpt(kk+1:end) ;
         else
            kpt = [] ;
         end
         kk = max(find(kpl<=knl(1))) ;
         if ~isempty(kk) & length(kpl)>kk,
            kpl = kpl(kk+1:end) ;
         else
            kpl = [] ;
         end
      end
      SIGN = 1 ;
   end
end

K = K(1:cnt,:) ;

if nargin==3,
   k = find(K(:,2)-K(:,1)<=Tmax) ;
   K = K(k,:) ;
end
