function    d3makeprhfile(tag)
%
%   Generate complete PRH file from a raw file using calibrations
%   and tag orientations in the tag deployment calibration file
%
%   mark johnson
%   majohnson@whoi.edu
%   last modified: 24 June 2006
%   modified for tag 3, stacy deruiter, july 2011
%
fprintf('Warning: No accurate pressure sensor, magnetometer or accelerometer calibrations applied. \n') 

loadcal(tag) ;

if ~exist('CAL','var')
   fprintf(' No CAL structure in the tag file - perform calibration before running makeprhfile') ;
   return
end

if ~exist('DECL','var')
   fprintf(' No DECL (magnetic field declination) variable in tag file - using DECL=0\n') ;
   DECL = 0 ;
elseif abs(DECL) > 0.5
    fprintf([' DECL converted from ' num2str(DECL) ' degrees to ' num2str(DECL*pi/180) ' radians for heading calculation\n']) ; 
    DECL = DECL*pi/180 ; %convert DECL to radians if it is in degrees!
end

[s,fs] = loadraw(tag) ;

[p,tempr] = calpressure(s,CAL,'none') ;
%run accelerometer calibration
ax = polyval(CAL.ACAL(1,:),s(:,1));
ay = polyval(CAL.ACAL(2,:),s(:,2));
az = polyval(CAL.ACAL(3,:),s(:,3));
A = [ax, ay, az];

%run accelerometer calibration
mx = polyval(CAL.MCAL(1,:),s(:,4));
my = polyval(CAL.MCAL(2,:),s(:,5));
mz = polyval(CAL.MCAL(3,:),s(:,6));
M = [mx, my, mz];

if ~exist('OTAB','var'),
   fprintf(' No OTAB (tag orientation) matrix in tag file - only computing tag frame variables\n') ;
   % save results
   saveprh(tag,'p','fs','A','M','tempr') ;
   return
end

% Compute the whale frame A and M matrices:
[Aw,Mw] = tag2whale(A,M,OTAB,fs) ;

% Compute whale frame pitch, roll, heading
[pitch roll] = a2pr(Aw) ;
[head vm incl] = m2h(Mw,pitch,roll) ;
head = head + DECL ; %head is in radians

% report on trustworthiness of heading estimate
fprintf(' After gimballing :-\n') ;
fprintf(' Mean Magnetic Field Inclination: %4.2f\260 (%4.2f\260 RMS)\n',...
       180/pi*mean(incl), 180/pi*std(incl)) ;

% save results
saveprh(tag,'p','pitch','roll','head','fs','Aw','Mw','A','M','tempr') ;
