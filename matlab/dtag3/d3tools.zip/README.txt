	           D3 Matlab Toolbox v3.0
	   Copyright (C) 2008-2012, Mark Johnson

These files are part of D3, a real-time patch panel scheduler
for digital signal processors.

The D3 Matlab toolbox is free software: you can redistribute it 
and/or modify it under the terms of the GNU General Public License 
as published by the Free Software Foundation, either version 3 of 
the License, or any later version.

This software is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with D3. If not, see <http://www.gnu.org/licenses/>.

